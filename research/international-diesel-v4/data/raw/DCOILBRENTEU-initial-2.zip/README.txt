-------------------------------------------------------------------
Series ID: DCOILBRENTEU
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=DCOILBRENTEU
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations, Initial Release Only
File Created: 2026-09-27 11:05 AM CDT
-------------------------------------------------------------------

-----------------------------------------------------------------  ---------------  -------------
Title                                                              Real-Time Start  Real-Time End
Crude Oil Prices: Brent - Europe                                   2011-04-06       Current
Source
U.S. Energy Information Administration                             2011-04-06       Current
Release
Spot Prices                                                        2011-04-06       Current
Units
Dollars per Barrel                                                 2011-04-06       Current
Frequency
Daily                                                              2011-04-06       Current
Seasonal Adjustment
Not Seasonally Adjusted                                            2011-04-06       Current
Notes
Definitions, Sources and Explanatory Notes                         2019-06-26       Current
(http://www.eia.doe.gov/dnav/pet/TblDefs/pet_pri_spt_tbldef2.asp)
-----------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2026-09-23
----------

